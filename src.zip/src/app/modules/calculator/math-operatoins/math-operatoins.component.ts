import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-math-operatoins',
  templateUrl: './math-operatoins.component.html',
  styleUrls: ['./math-operatoins.component.css']
})
export class MathOperatoinsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
