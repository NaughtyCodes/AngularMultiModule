import { Component, OnInit } from '@angular/core';
import { ViewChild, AfterViewInit, ElementRef, Input, HostListener } from '@angular/core';
import { HeaderComponent } from '../header/header.component';

@Component({
  selector: 'app-call',
  templateUrl: './call.component.html',
  styleUrls: ['./call.component.css']
})
export class CallComponent implements OnInit {

  @ViewChild("callPara", {read: ElementRef}) callPara: ElementRef;
  public currentUser: String = "Krish Nan";
  public isDisplay: Boolean = true;
 
  constructor() {
    
  }

 // @HostListener('click')
  click(event) {
    //alert('calling from header component');
    this.callPara.nativeElement.style.display = (this.isDisplay) ? 'block' : 'none';
    this.isDisplay = (this.isDisplay) ? false : true;
  }

  ngAfterViewInit() {
    console.log(this.callPara.nativeElement);
    this.callPara.nativeElement.style.display = 'none';
  }
  
  ngOnInit() {
    
  }




}
